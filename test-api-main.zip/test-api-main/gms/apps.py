from django.apps import AppConfig


class GmsConfig(AppConfig):
    name = 'gms'
