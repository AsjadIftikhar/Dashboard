from django.apps import AppConfig


class HciConfig(AppConfig):
    name = 'hci'
